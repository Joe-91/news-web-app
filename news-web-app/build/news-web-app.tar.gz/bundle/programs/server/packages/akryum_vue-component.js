(function () {



/* Exports */
Package._define("akryum:vue-component");

})();
