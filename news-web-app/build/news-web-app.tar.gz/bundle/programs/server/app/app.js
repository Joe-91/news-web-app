var require = meteorInstall({"imports":{"api":{"collections":{"Links.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/collections/Links.js                                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
module.exportDefault(new Mongo.Collection('links'));
///////////////////////////////////////////////////////////////////////

}},"methods":{"createLink.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/methods/createLink.js                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Links;
module.link("../collections/Links.js", {
  default(v) {
    Links = v;
  }

}, 2);
Meteor.methods({
  'createLink'(title, url) {
    check(url, String);
    check(title, String);
    return Links.insert({
      url,
      title,
      createdAt: new Date()
    });
  }

});
///////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/methods/index.js                                      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.link("./createLink");
///////////////////////////////////////////////////////////////////////

}},"publications":{"index.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/publications/index.js                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.link("./links");
///////////////////////////////////////////////////////////////////////

},"links.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/publications/links.js                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Links;
module.link("../collections/Links.js", {
  default(v) {
    Links = v;
  }

}, 1);
Meteor.publish('links', function () {
  return Links.find();
});
///////////////////////////////////////////////////////////////////////

}},"fixtures.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/fixtures.js                                           //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Links;
module.link("./collections/Links.js", {
  default(v) {
    Links = v;
  }

}, 1);
Meteor.startup(() => {
  // if the Links collection is empty
  if (Links.find().count() === 0) {
    const data = [{
      title: 'Do the Tutorial',
      url: 'https://www.meteor.com/try',
      createdAt: new Date()
    }, {
      title: 'Follow the Guide',
      url: 'http://guide.meteor.com',
      createdAt: new Date()
    }, {
      title: 'Read the Docs',
      url: 'https://docs.meteor.com',
      createdAt: new Date()
    }, {
      title: 'Discussions',
      url: 'https://forums.meteor.com',
      createdAt: new Date()
    }];
    data.forEach(link => Links.insert(link));
  }
});
///////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.link("../imports/api/fixtures");
module.link("../imports/api/methods");
module.link("../imports/api/publications");
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".vue"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMvTGlua3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMvY3JlYXRlTGluay5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWV0aG9kcy9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHVibGljYXRpb25zL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9wdWJsaWNhdGlvbnMvbGlua3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ZpeHR1cmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJNb25nbyIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiZXhwb3J0RGVmYXVsdCIsIkNvbGxlY3Rpb24iLCJNZXRlb3IiLCJjaGVjayIsIkxpbmtzIiwiZGVmYXVsdCIsIm1ldGhvZHMiLCJ0aXRsZSIsInVybCIsIlN0cmluZyIsImluc2VydCIsImNyZWF0ZWRBdCIsIkRhdGUiLCJwdWJsaXNoIiwiZmluZCIsInN0YXJ0dXAiLCJjb3VudCIsImRhdGEiLCJmb3JFYWNoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEtBQUo7QUFBVUMsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRixPQUFLLENBQUNHLENBQUQsRUFBRztBQUFDSCxTQUFLLEdBQUNHLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBVkYsTUFBTSxDQUFDRyxhQUFQLENBRWUsSUFBSUosS0FBSyxDQUFDSyxVQUFWLENBQXFCLE9BQXJCLENBRmYsRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJQyxNQUFKO0FBQVdMLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0ksUUFBTSxDQUFDSCxDQUFELEVBQUc7QUFBQ0csVUFBTSxHQUFDSCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlJLEtBQUo7QUFBVU4sTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDSyxPQUFLLENBQUNKLENBQUQsRUFBRztBQUFDSSxTQUFLLEdBQUNKLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUssS0FBSjtBQUFVUCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWixFQUFzQztBQUFDTyxTQUFPLENBQUNOLENBQUQsRUFBRztBQUFDSyxTQUFLLEdBQUNMLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFJdElHLE1BQU0sQ0FBQ0ksT0FBUCxDQUFlO0FBQ2IsZUFBYUMsS0FBYixFQUFvQkMsR0FBcEIsRUFBeUI7QUFDdkJMLFNBQUssQ0FBQ0ssR0FBRCxFQUFNQyxNQUFOLENBQUw7QUFDQU4sU0FBSyxDQUFDSSxLQUFELEVBQVFFLE1BQVIsQ0FBTDtBQUVBLFdBQU9MLEtBQUssQ0FBQ00sTUFBTixDQUFhO0FBQ2xCRixTQURrQjtBQUVsQkQsV0FGa0I7QUFHbEJJLGVBQVMsRUFBRSxJQUFJQyxJQUFKO0FBSE8sS0FBYixDQUFQO0FBS0Q7O0FBVlksQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBZixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEU7Ozs7Ozs7Ozs7O0FDQUFELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJSSxNQUFKO0FBQVdMLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0ksUUFBTSxDQUFDSCxDQUFELEVBQUc7QUFBQ0csVUFBTSxHQUFDSCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlLLEtBQUo7QUFBVVAsTUFBTSxDQUFDQyxJQUFQLENBQVkseUJBQVosRUFBc0M7QUFBQ08sU0FBTyxDQUFDTixDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRzFFRyxNQUFNLENBQUNXLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLFlBQVk7QUFDbEMsU0FBT1QsS0FBSyxDQUFDVSxJQUFOLEVBQVA7QUFDRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDSEEsSUFBSVosTUFBSjtBQUFXTCxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNJLFFBQU0sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNHLFVBQU0sR0FBQ0gsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJSyxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNPLFNBQU8sQ0FBQ04sQ0FBRCxFQUFHO0FBQUNLLFNBQUssR0FBQ0wsQ0FBTjtBQUFROztBQUFwQixDQUFyQyxFQUEyRCxDQUEzRDtBQUcxRUcsTUFBTSxDQUFDYSxPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBLE1BQUlYLEtBQUssQ0FBQ1UsSUFBTixHQUFhRSxLQUFiLE9BQXlCLENBQTdCLEVBQWdDO0FBQzlCLFVBQU1DLElBQUksR0FBRyxDQUNYO0FBQ0VWLFdBQUssRUFBRSxpQkFEVDtBQUVFQyxTQUFHLEVBQUUsNEJBRlA7QUFHRUcsZUFBUyxFQUFFLElBQUlDLElBQUo7QUFIYixLQURXLEVBTVg7QUFDRUwsV0FBSyxFQUFFLGtCQURUO0FBRUVDLFNBQUcsRUFBRSx5QkFGUDtBQUdFRyxlQUFTLEVBQUUsSUFBSUMsSUFBSjtBQUhiLEtBTlcsRUFXWDtBQUNFTCxXQUFLLEVBQUUsZUFEVDtBQUVFQyxTQUFHLEVBQUUseUJBRlA7QUFHRUcsZUFBUyxFQUFFLElBQUlDLElBQUo7QUFIYixLQVhXLEVBZ0JYO0FBQ0VMLFdBQUssRUFBRSxhQURUO0FBRUVDLFNBQUcsRUFBRSwyQkFGUDtBQUdFRyxlQUFTLEVBQUUsSUFBSUMsSUFBSjtBQUhiLEtBaEJXLENBQWI7QUF1QkFLLFFBQUksQ0FBQ0MsT0FBTCxDQUFhcEIsSUFBSSxJQUFJTSxLQUFLLENBQUNNLE1BQU4sQ0FBYVosSUFBYixDQUFyQjtBQUNEO0FBQ0YsQ0E1QkQsRTs7Ozs7Ozs7Ozs7QUNIQUQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUJBQVo7QUFBdUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaO0FBQXNDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBuZXcgTW9uZ28uQ29sbGVjdGlvbignbGlua3MnKTtcclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcclxuaW1wb3J0IExpbmtzIGZyb20gJy4uL2NvbGxlY3Rpb25zL0xpbmtzLmpzJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAnY3JlYXRlTGluaycodGl0bGUsIHVybCkge1xyXG4gICAgY2hlY2sodXJsLCBTdHJpbmcpO1xyXG4gICAgY2hlY2sodGl0bGUsIFN0cmluZyk7XHJcblxyXG4gICAgcmV0dXJuIExpbmtzLmluc2VydCh7XHJcbiAgICAgIHVybCxcclxuICAgICAgdGl0bGUsXHJcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcclxuICAgIH0pO1xyXG4gIH0sXHJcbn0pO1xyXG4iLCJpbXBvcnQgJy4vY3JlYXRlTGluaydcclxuIiwiaW1wb3J0ICcuL2xpbmtzJ1xyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IExpbmtzIGZyb20gJy4uL2NvbGxlY3Rpb25zL0xpbmtzLmpzJztcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdsaW5rcycsIGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gTGlua3MuZmluZCgpO1xyXG59KTtcclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCBMaW5rcyBmcm9tICcuL2NvbGxlY3Rpb25zL0xpbmtzLmpzJztcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxuICAvLyBpZiB0aGUgTGlua3MgY29sbGVjdGlvbiBpcyBlbXB0eVxyXG4gIGlmIChMaW5rcy5maW5kKCkuY291bnQoKSA9PT0gMCkge1xyXG4gICAgY29uc3QgZGF0YSA9IFtcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiAnRG8gdGhlIFR1dG9yaWFsJyxcclxuICAgICAgICB1cmw6ICdodHRwczovL3d3dy5tZXRlb3IuY29tL3RyeScsXHJcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdGl0bGU6ICdGb2xsb3cgdGhlIEd1aWRlJyxcclxuICAgICAgICB1cmw6ICdodHRwOi8vZ3VpZGUubWV0ZW9yLmNvbScsXHJcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdGl0bGU6ICdSZWFkIHRoZSBEb2NzJyxcclxuICAgICAgICB1cmw6ICdodHRwczovL2RvY3MubWV0ZW9yLmNvbScsXHJcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdGl0bGU6ICdEaXNjdXNzaW9ucycsXHJcbiAgICAgICAgdXJsOiAnaHR0cHM6Ly9mb3J1bXMubWV0ZW9yLmNvbScsXHJcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBkYXRhLmZvckVhY2gobGluayA9PiBMaW5rcy5pbnNlcnQobGluaykpO1xyXG4gIH1cclxufSk7XHJcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9hcGkvZml4dHVyZXMnXHJcbmltcG9ydCAnLi4vaW1wb3J0cy9hcGkvbWV0aG9kcydcclxuaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS9wdWJsaWNhdGlvbnMnXHJcbiJdfQ==
